package com.example.jocelyn.calculadoralinearlayout;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText operador1,operador2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        operador1=(EditText)findViewById(R.id.edtNum1);
        operador2=(EditText)findViewById(R.id.edtNum2);
    }

    public void Sumar(View view) {
        /*[convertimos a número los valores introducidos y operamos*/
        int n1=Integer.parseInt(operador1.getText().toString());
        int n2=Integer.parseInt(operador2.getText().toString());
        int sum=n1+n2;
        mostrar(sum);
    }

    public void Restar(View view) {
        int n1=Integer.parseInt(operador1.getText().toString());
        int n2=Integer.parseInt(operador2.getText().toString());
        int sum=n1-n2;
        mostrar(sum);

    }

    public void Multiplicar(View view) {
        int n1=Integer.parseInt(operador1.getText().toString());
        int n2=Integer.parseInt(operador2.getText().toString());
        int sum=n1*n2;
        mostrar(sum);
    }

    public void Dividir(View view) {
        int n1=Integer.parseInt(operador1.getText().toString());
        int n2=Integer.parseInt(operador2.getText().toString());
        int sum=n1/n2;
        mostrar(sum);
    }
    public void Modulo(View view) {
        int n1=Integer.parseInt(operador1.getText().toString());
        int n2=Integer.parseInt(operador2.getText().toString());
        int sum=n1%n2;
        mostrar(sum);
    }
    private void mostrar(int res) {
        Toast.makeText(this, "Resultado operación: "+ res, Toast.LENGTH_LONG).show();
    }
}
